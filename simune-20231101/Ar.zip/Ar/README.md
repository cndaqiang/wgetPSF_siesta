Ground State
Ar [1s2 2s2 2p6] 3s2 3p6 3d0 4f0
