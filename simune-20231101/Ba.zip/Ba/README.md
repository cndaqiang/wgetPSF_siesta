For this pseudo it necessary to add the basis set block in the fdf input file in order to run SUESTA.
The basis set block in this folder does not include set the rcut-off for the first and second orbital.
Thus, SIESTA will use the Energyshift and the splitnorm values to define the rcut-off.

Ground State
La [1s2 2s2 2p6 3s2 3p6 3d10 4s2 4p6 4d10 5s2 5p6] 5s2 5p6 5d1 4f0
