Ground state
He 1s2 2p0 3d0 4f0
