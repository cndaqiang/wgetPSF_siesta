Ground State
W [1s2 2s2 2p6 3s2 3p6 3d10 4s2 4p6 4d10 5s2 5p6 4f14] 6s2 6p0 5d4 5f0
